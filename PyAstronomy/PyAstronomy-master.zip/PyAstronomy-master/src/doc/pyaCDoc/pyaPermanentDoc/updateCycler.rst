Realizing an update cycle
==========================

.. currentmodule:: PyAstronomy.pyaC.pyaPermanent
.. autoclass:: PyAUpdateCycle
   :members: