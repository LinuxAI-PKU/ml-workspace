List of PyA exceptions
===========================

Below you find a list of all implemented PyA exceptions. If possible, the
exceptions are sorted by category.

.. currentModule:: PyAstronomy

PyA value exceptions
----------------------

.. automodule:: pyaC.pyaErrors.pyaValErrs
   :members:
   :undoc-members:

PyA uncategorized exceptions
------------------------------

.. automodule:: pyaC.pyaErrors.pyaOtherErrors
   :members:
   :undoc-members: