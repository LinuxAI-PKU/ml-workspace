Show a warning 
=====================

PyA exception classes may also be used to show warnings.
To to do, call the *warn* function.

.. currentmodule:: PyAstronomy.pyaC.pyaErrors
.. autofunction:: warn