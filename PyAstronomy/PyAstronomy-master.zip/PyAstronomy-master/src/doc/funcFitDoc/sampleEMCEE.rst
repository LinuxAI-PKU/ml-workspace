API of sampleEMCEE
=======================

.. currentmodule:: PyAstronomy.funcFit
.. autofunction:: sampleEMCEE