Parameter Management
======================

.. currentmodule:: PyAstronomy.funcFit
.. autoclass:: Params
   :members: