Thermal broadening
====================

.. p23ready

.. currentModule:: PyAstronomy.pyasl
.. autofunction:: thermalBroadeningWidth